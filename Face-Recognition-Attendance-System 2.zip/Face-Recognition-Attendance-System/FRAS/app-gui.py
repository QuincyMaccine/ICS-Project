from curses import window
from turtle import color
from Capture_Image import takeImages
from Recognize import recognize_attendence
from report import reports
from automail import mail
import check_camera
import Capture_Image
import Train_Image
import Recognize
import csv
import cv2
import os
from check_camera import camera
from Capture_Image import is_number
import tkinter as tk
from tkinter import font as tkfont
from tkinter import *
import tkinter.ttk as ttk
from tkinter import messagebox,PhotoImage
import glob


names = set()

def run():
    os.system('python  FRAS/automail.py') 

def attendance():
        root = Tk()
        root.title("ATTENDANCE REPORT")
        width = 800
        height = 400 
        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()
        x = (screen_width/2) - (width/2)
        y = (screen_height/2) - (height/2)
        root.geometry("%dx%d+%d+%d" % (width, height, x, y))
        

        TableMargin = Frame(root, width=500)
        TableMargin.pack(side=TOP)
        scrollbarx = Scrollbar(TableMargin, orient=HORIZONTAL)
        scrollbary = Scrollbar(TableMargin, orient=VERTICAL)
        tree = ttk.Treeview(TableMargin, columns=("Id", "Name", "Date","Time"), height=400, selectmode="extended", yscrollcommand=scrollbary.set, xscrollcommand=scrollbarx.set)
        scrollbary.config(command=tree.yview)
        scrollbary.pack(side=RIGHT, fill=Y)
        scrollbarx.config(command=tree.xview)
        scrollbarx.pack(side=BOTTOM, fill=X)
        tree.heading('Id', text="Id", anchor=W)
        tree.heading('Name', text="Name", anchor=W)
        tree.heading('Date', text="Date", anchor=W)
        tree.heading('Time', text="Time", anchor=W)
        tree.column('#0', stretch=NO, minwidth=0, width=0)
        tree.column('#1', stretch=NO, minwidth=0, width=150)
        tree.column('#2', stretch=NO, minwidth=0, width=150)
        tree.column('#3', stretch=NO, minwidth=0, width=150)
        tree.pack()

        latest_csv = max(glob.glob('FRAS/Attendance/Attendance_*.csv'), key=os.path.getctime) 
        

        with open(latest_csv) as f:
         reader = csv.DictReader(f, delimiter=',')
         for row in reader:
             Id = row['Id']
             Name = row['Name']
             Date = row['Date']
             Time = row['Time']
             tree.insert("", 0, values=(Id, Name, Date,Time))


class MainUI(tk.Tk):

    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)
        global names
        with open("FRAS/nameslist.txt", "r") as f:
            x = f.read()
            z = x.rstrip().split(" ")
            for i in z:
                names.add(i)
        self.title_font = tkfont.Font(family='papyrus', size=50, weight="bold")
        self.title("SCHOOL ATTENDANCE SYSTEM")
        self.resizable(False, False)
        self.geometry("450x500")
        self.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.active_name = None
        container = tk.Frame(self)
        container.grid(sticky="nsew")
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)
        
        self.frames = {}
        for F in (StartPage, PageOne, PageTwo, PageThree, PageFour):
            page_name = F.__name__
            frame = F(parent=container, controller=self)
            self.frames[page_name] = frame
            frame.grid(row=0, column=0, sticky="nsew")
        self.show_frame("StartPage")

    def show_frame(self, page_name):
            frame = self.frames[page_name]
            frame.tkraise()

    def on_closing(self):

        if messagebox.askokcancel("Quit", "Are you sure?"):
            global names
            f =  open("nameslist.txt", "a+")
            for i in names:
                    f.write(i+" ")
            self.destroy()


class StartPage(tk.Frame):

        def __init__(self, parent, controller):
            tk.Frame.__init__(self, parent)
            self.controller = controller
            #load = Image.open("homepagepic.png")
            #load = load.resize((250, 250), Image.ANTIALIAS)
            render = PhotoImage(file='FRAS/homepagepic.png')
            img = tk.Label(self, image=render)
            img.image = render
            img.grid(row=1, column=0, rowspan=5, sticky="nwse")
            label = tk.Label(self, text="        Home Page        ", font=self.controller.title_font,fg="#FFFFFF")
            label.grid(row=0, sticky="ew")
            my_font=('papyrus', 15, 'bold')


            button1 = tk.Button(self, text="Check Camera", fg="#ffffff", bg="#263942",font=my_font,width=20,command=lambda:camera())


            button2 = tk.Button(self, text="   Take Attendance   ", fg="#ffffff", bg="#263942",font=my_font,width=20,command=lambda:recognize_attendence())
            

            button3 = tk.Button(self, text="   Check Attendance ", fg="#ffffff", bg="#263942",font=my_font,width=20,command=lambda:attendance())

            button5 = tk.Button(self, text="   Generate Reports ", fg="#ffffff", bg="#263942",font=my_font,width=20,command=lambda:reports())

            button6 = tk.Button(self, text="   Email Reports ", fg="#ffffff", bg="#263942",font=my_font,width=20,command=lambda:mail())


            button4 = tk.Button(self,font=my_font, text="Quit", fg="#c43939", bg="#ffffff", command=self.on_closing)


            button1.grid(row=1, column=0, ipady=3, ipadx=7)
            button2.grid(row=2, column=0, ipady=3, ipadx=2)
            button3.grid(row=3, column=0, ipady=3, ipadx=2)
            button5.grid(row=4, column=0, ipady=3, ipadx=2)
            button6.grid(row=5, column=0, ipady=3, ipadx=2)
            button4.grid(row=6, column=0, ipady=3, ipadx=10)


        def on_closing(self):
            if messagebox.askokcancel("Quit", "Are you sure?"):
                global names
                with open("nameslist.txt", "w") as f:
                    for i in names:
                        f.write(i + " ")
                self.controller.destroy()

        


class PageOne(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

class PageTwo(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

class PageThree(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        

class PageFour(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller

 


app = MainUI()
app.iconphoto(False, tk.PhotoImage(file='FRAS/icon.ico'))
app.mainloop()





