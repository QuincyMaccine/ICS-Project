import os
import pandas as pd
from openpyxl import Workbook
import csv
os.chdir('FRAS/StudentDetails')




wb = Workbook()
ws = wb.active
with open('StudentDetails.csv', 'r') as f:
    for row in csv.reader(f):
        ws.append(row)
wb.save('StudentDetails.xlsx')