def mail():

 import os
 import yagmail

 receiver = "quincymagoma5@gmail.com"  # receiver email address
 body = "Attached are the attendance reports"  # email body
 filename = "FRAS/Attendance"+os.sep+"Absent.xlsx"  # attach the file
 filename2 = "FRAS/Attendance"+os.sep+"Student Attendance.pdf"  # attach the file
 filename3 = "FRAS/StudentDetails"+os.sep+"StudentDetails.xlsx"  # attach the file
 filename4 = "FRAS/Attendance"+os.sep+"StudentAttendance.xlsx"  # attach the file

# mail information
 yag = yagmail.SMTP("quincymagoma5@gmail.com", "fpiuqywozjlvspyb")


# sent the mail
 yag.send(
    to=receiver,
    subject="Attendance Report",  # email subject
    contents=body,  # email body
    attachments=[filename2,filename,filename3,filename4] # file attached
)
 print("Email Sent")
