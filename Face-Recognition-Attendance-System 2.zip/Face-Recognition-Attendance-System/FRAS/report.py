def reports():
 import os
 from pathlib import Path
 import numpy as np
 import pandas as pd
 import glob
 import shutil
 import csv
 from weasyprint import HTML,CSS
 import matplotlib.pyplot as plt
 from matplotlib.backends.backend_pdf import PdfPages
 import pdfkit as pdf
 from fpdf import FPDF
 import yagmail




 os.chdir('FRAS/Attendance')
 extension='csv'
 all_filenames = [i for i in glob.glob('*.{}'.format(extension))]
 fileNumber=len(all_filenames)

#combine all files in the list
 combined_csv = pd.concat([pd.read_csv(f) for f in all_filenames ])

#export to csv
 combined_csv.to_csv( "combined_csv.csv", index=False, encoding='utf-8-sig')

 df = pd.read_csv('combined_csv.csv')
 Duplicate=df[df.duplicated()]
 Final=df.drop_duplicates(keep='first')

 df=Final




 df_result = df[df['Id'] == 118465]
 Present1=len(df_result)
 TotalHours1=(fileNumber-1)
 HoursAbsent1=(TotalHours1-Present1)
 PercentageAbsent1=(HoursAbsent1/TotalHours1)*100



 df_result2 = df[df['Id'] == 112112]
 Present2=len(df_result2)
 TotalHours2=(fileNumber-1)
 HoursAbsent2=(TotalHours2-Present2)
 PercentageAbsent2=(HoursAbsent2/TotalHours2)*100

 report={'Id':["118465","112112"],'Name':["MaccineQuincy","OmbatiDavis"],'Classes Present':[Present1,Present2],'Classes Absent':[HoursAbsent1,HoursAbsent2],'Percentage':[PercentageAbsent1,PercentageAbsent2]}

 dataframe=pd.DataFrame(report)
 dataframe.to_excel('Absent.xlsx')
 dataframe.to_html('f.html')
 nazivFajla='z.pdf'
 pdf.from_file('f.html', nazivFajla)

 report2=pd.DataFrame(df_result)
 report3=pd.DataFrame(df_result2)

 def output_df_to_pdf(pdf, df):
    # A cell is a rectangular area, possibly framed, which contains some text
    # Set the width and height of cell
    table_cell_width = 25
    table_cell_height = 6
    # Select a font as Arial, bold, 8
    pdf.set_font('Arial', 'B', 8)
    
    # Loop over to print column names
    cols = df.columns
    for col in cols:
        pdf.cell(table_cell_width, table_cell_height, col, align='C', border=1)
    # Line break
    pdf.ln(table_cell_height)
    # Select a font as Arial, regular, 10
    pdf.set_font('Arial', '', 10)
    # Loop over to print each data in the table
    for row in df.itertuples():
        for col in cols:
            value = str(getattr(row, col))
            pdf.cell(table_cell_width, table_cell_height, value, align='C', border=1)
        pdf.ln(table_cell_height)

 pdf = FPDF()
 pdf.add_page()
 pdf.set_font('Arial', 'B', 16)

## Title
 pdf.cell(40, 10, 'Student Attendance Reports')

## Line breaks
 pdf.ln(20)

 output_df_to_pdf(pdf,report2)

 pdf.ln(10)

 output_df_to_pdf(pdf,report3)

 pdf.output('Student Attendance.pdf','F')

 print("Reports Generated")















    








